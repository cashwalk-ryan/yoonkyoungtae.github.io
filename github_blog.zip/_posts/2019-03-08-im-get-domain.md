---
layout: post
title: 도메인이 생겼다.
tags: [기타]
date: 2019-03-08 12:00:00
sitemap :
  changefreq : daily
  priority : 1.0
---

# 도메인이 생겼다.
이번에 .dev 도메인 1년 이용권을 우연히 얻게 되었다.  
이 참에 나도 도메인을 하나 가져볼까 해서 처음으로 신청해 보았다.  
웹알못이라 그동안 들어본 단어들로만 찾 어려움이 많았다. (A는뭐고 CNAME은 뭐지..?)

이것저것 자료를 찾아보며 등록을 완료하였다.  
앞으로 이 블로그 진입은 www.android-blog.dev 로 접속하면 된다.  

아래는 도메인을 등록하면서 도움이 되었던 블로그 포스팅들이다.  
나중에도 참고 할 수 있을것 같아서 첨부해두었다.

**무료로 내 블로그에 SSL[HTTPS] 적용하기**  
<https://suitee.me/2019/02/14/how-to-setup-free-ssl-2/>

**HTTPS 적용 후 구글 Search Console 필수 설정**  
<https://blog.gaerae.com/2018/01/https-google-search-console.html>
